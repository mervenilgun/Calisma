﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace slll
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Random numberGen = new Random();

            int numberOfAttempts = 0;
            int attempt = 0;
            
            while (numberOfAttempts !=6)
            {
                numberOfAttempts = numberGen.Next(1, 7);
                Console.WriteLine("Tom rolled: " + numberOfAttempts + ".");
                numberOfAttempts++;
            }

            Console.WriteLine("It took Tom" + numberOfAttempts + " attempts to roll a six.");
            Console.ReadKey();

        }
    }
}
