﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops
{
    class Program
    {
        //girilen sayının asal olup olmadığını bulma
        static void Main(string[] args)
        {
            string[] student = new string[3] { "Engin", "Derin", "Salih" };
            foreach (var student in students)
        }
        Console.WriteLine(student);
        {
            Console.ReadLine(student);
        {
           private static bool IsPrimeNumber(int number)

        {
            bool result = true;
            for (int i = 2; i < number-1; i++)
        }
        if (number%i==0)
            {
            result = false;
            i = number;
            }
        Console.WriteLine(number);
            number--;
        }
    }
}
