﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    internal class internal_interface_RecordNotFoundException
    {
        public internal_interface_RecordNotFoundException(string message) : base(message)
        {

        }
    }
}
