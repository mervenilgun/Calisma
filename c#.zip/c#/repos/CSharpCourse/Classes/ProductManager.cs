﻿using System;

namespace Classes
{
    internal class ProductManager
    {
        public ProductManager()
        {
        }

        internal void Add()
        {
            throw new NotImplementedException();
        }

        internal void Update()
        {
            throw new NotImplementedException();
        }
    }
}