﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    internal class Program
    {
        private static object costumers;

        public static int Id { get; private set; }

        private static void Main(string[] args)
        {
            Main(args, Id);
        }

        static void Main(string[] args, int ıd)
        {
            CostumersManager costumersManager = new CostumersManager();
            costumersManager.Add();
            costumersManager.Update();

            ProductManager productManager = new ProductManager();
            productManager.Add();
            productManager.Update();

            Costumers.costumers = new Costumers();
            costumers.City = "Ankara";
            costumers.Id = 1;
            costumers.FirstName = "Engin";
            costumers.LastName = "Demiroğ";

            Costumers costumers2 = new Costumers
            {
                ıd = 2,
                City = "İstanbul",
                FirstName = "Derin",
                LastName = "Demiroğ"
            };

            Console.WriteLine(costumers2.FirstName);

            Console.ReadLine();


        }
    }

    internal class CostumersManager
    {
        internal void Add()
        {
            throw new NotImplementedException();
        }

        internal void Update()
        {
            throw new NotImplementedException();
        }
    }
}
